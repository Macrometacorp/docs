const photoniqEdsWs = require('photoniq-eds-sdk')

console.log("");